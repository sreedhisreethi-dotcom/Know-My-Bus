let selectedType="Government";
const routes={
Coimbatore:{
Government:[
["Kovai Bus 1","06:00",["Pollachi Bus Stand","Vadakkipalayam Pirivu","Kinathukadavu","Othakalmandapam","Eachanari","Ukkadam"]],
["Kovai Bus 2","06:30",["Pollachi Bus Stand","Vadakkipalayam Pirivu","Kinathukadavu","Othakalmandapam","Eachanari","Ukkadam"]],
["Kovai Bus 3","07:00",["Pollachi Bus Stand","Vadakkipalayam Pirivu","Kinathukadavu","Othakalmandapam","Eachanari","Ukkadam"]],
["Kovai Bus 4","07:30",["Pollachi Bus Stand","Vadakkipalayam Pirivu","Kinathukadavu","Othakalmandapam","Eachanari","Ukkadam"]],
["Kovai Bus 5","08:00",["Pollachi Bus Stand","Vadakkipalayam Pirivu","Kinathukadavu","Othakalmandapam","Eachanari","Ukkadam"]],
["Kovai Bus 6","08:30",["Pollachi Bus Stand","Vadakkipalayam Pirivu","Kinathukadavu","Othakalmandapam","Eachanari","Ukkadam"]],
["Kovai Bus 7","09:00",["Pollachi Bus Stand","Vadakkipalayam Pirivu","Kinathukadavu","Othakalmandapam","Eachanari","Ukkadam"]],
["Kovai Bus 8","09:30",["Pollachi Bus Stand","Vadakkipalayam Pirivu","Kinathukadavu","Othakalmandapam","Eachanari","Ukkadam"]],
["Kovai Bus 9","10:00",["Pollachi Bus Stand","Vadakkipalayam Pirivu","Kinathukadavu","Othakalmandapam","Eachanari","Ukkadam"]],
["Kovai Bus 10","10:30",["Pollachi Bus Stand","Vadakkipalayam Pirivu","Kinathukadavu","Othakalmandapam","Eachanari","Ukkadam"]]
],
Private:[
["Private Kovai 1","06:15",["Pollachi Bus Stand","Vadakkipalayam Pirivu","Kovil Palayam","Thamaraikulam","Kinathukadavu","Othakalmandapam","Malumichampatti","Karpagam College","Eachanari","Sundarapuram","Ukkadam Bus Stand"]],
["Private Kovai 2","06:45",["Pollachi Bus Stand","Vadakkipalayam Pirivu","Kovil Palayam","Thamaraikulam","Kinathukadavu","Othakalmandapam","Malumichampatti","Karpagam College","Eachanari","Sundarapuram","Ukkadam Bus Stand"]],
["Private Kovai 3","07:15",["Pollachi Bus Stand","Vadakkipalayam Pirivu","Kovil Palayam","Thamaraikulam","Kinathukadavu","Othakalmandapam","Malumichampatti","Karpagam College","Eachanari","Sundarapuram","Ukkadam Bus Stand"]],
["Private Kovai 4","07:45",["Pollachi Bus Stand","Vadakkipalayam Pirivu","Kovil Palayam","Thamaraikulam","Kinathukadavu","Othakalmandapam","Malumichampatti","Karpagam College","Eachanari","Sundarapuram","Ukkadam Bus Stand"]],
["Private Kovai 5","08:15",["Pollachi Bus Stand","Vadakkipalayam Pirivu","Kovil Palayam","Thamaraikulam","Kinathukadavu","Othakalmandapam","Malumichampatti","Karpagam College","Eachanari","Sundarapuram","Ukkadam Bus Stand"]],
["Private Kovai 6","08:45",["Pollachi Bus Stand","Vadakkipalayam Pirivu","Kovil Palayam","Thamaraikulam","Kinathukadavu","Othakalmandapam","Malumichampatti","Karpagam College","Eachanari","Sundarapuram","Ukkadam Bus Stand"]],
["Private Kovai 7","09:15",["Pollachi Bus Stand","Vadakkipalayam Pirivu","Kovil Palayam","Thamaraikulam","Kinathukadavu","Othakalmandapam","Malumichampatti","Karpagam College","Eachanari","Sundarapuram","Ukkadam Bus Stand"]],
["Private Kovai 8","09:45",["Pollachi Bus Stand","Vadakkipalayam Pirivu","Kovil Palayam","Thamaraikulam","Kinathukadavu","Othakalmandapam","Malumichampatti","Karpagam College","Eachanari","Sundarapuram","Ukkadam Bus Stand"]],
["Private Kovai 9","10:15",["Pollachi Bus Stand","Vadakkipalayam Pirivu","Kovil Palayam","Thamaraikulam","Kinathukadavu","Othakalmandapam","Malumichampatti","Karpagam College","Eachanari","Sundarapuram","Ukkadam Bus Stand"]],
["Private Kovai 10","10:45",["Pollachi Bus Stand","Vadakkipalayam Pirivu","Kovil Palayam","Thamaraikulam","Kinathukadavu","Othakalmandapam","Malumichampatti","Karpagam College","Eachanari","Sundarapuram","Ukkadam Bus Stand"]]
]},
Ooty:{Government:[
["Ooty Bus 1","05:30",["Pollachi Bus Stand","Ooty"]],
["Ooty Bus 2","06:30",["Pollachi Bus Stand","Ooty"]]
],Private:[]},
Tiruppur:{Government:[
["Tiruppur Bus 1","07:00",["Pollachi Bus Stand","Tiruppur"]],
["Tiruppur Bus 2","09:00",["Pollachi Bus Stand","Tiruppur"]],
["Tiruppur Bus 3","15:00",["Pollachi Bus Stand","Tiruppur"]],
["Tiruppur Bus 4","19:00",["Pollachi Bus Stand","Tiruppur"]]
],Private:[]}
};

function setType(t){
 selectedType=t; document.getElementById("gov").classList.toggle("active",t==="Government"); document.getElementById("private").classList.toggle("active",t==="Private");
}
function mins(t){let [h,m]=t.split(":").map(Number);return h*60+m}
function fmt(t){let [h,m]=t.split(":").map(Number);let ap=h>=12?"PM":"AM";h=h%12||12;return `${h}:${String(m).padStart(2,"0")} ${ap}`}

const fares={
 Coimbatore:{Government:20,Private:25},
 Ooty:{Government:90,Private:110},
 Tiruppur:{Government:30,Private:35}
};

function addMinutesToTime(time, add){
 let total=mins(time)+add;
 total=((total%1440)+1440)%1440;
 let h=Math.floor(total/60), m=total%60;
 return `${String(h).padStart(2,"0")}:${String(m).padStart(2,"0")}`;
}
function getDepartures(bus, dest, type){
 // Initial departures supplied by the project.
 // Coimbatore: same bus becomes available again every 2.5 hours.
 // Ooty/Tiruppur: same bus becomes available again every 4.5 hours.
 const cycle = dest==="Coimbatore" ? 150 : 270;
 const base=mins(bus[1]);
 const dayEnd=24*60;
 const times=[];
 for(let t=base;t<dayEnd;t+=cycle){
   times.push({time:`${String(Math.floor(t/60)).padStart(2,"0")}:${String(t%60).padStart(2,"0")}`, initial:t===base});
 }
 return times;
}

function formatWait(minutes){
 let h=Math.floor(minutes/60), m=minutes%60;
 if(h>0 && m>0) return `${h} hour${h===1?"":"s"} ${m} minute${m===1?"":"s"}`;
 if(h>0) return `${h} hour${h===1?"":"s"}`;
 return `${m} minute${m===1?"":"s"}`;
}

let language="en";
function toggleLanguage(){
 language=language==="en"?"ta":"en";
 document.getElementById("langBtn").textContent=language==="en"?"தமிழ்":"English";
 document.querySelector(".logo").textContent=language==="en"?"🚌 Know My Bus":"🚌 என் பேருந்து";
 document.querySelector(".tag").textContent=language==="en"?"AI Route Assistant • Prototype":"AI வழித்தட உதவியாளர் • மாதிரி";
 document.querySelector(".hero h1").textContent=language==="en"?"Find the right bus.":"சரியான பேருந்தை கண்டுபிடிக்கவும்.";
 document.querySelector(".hero p").textContent=language==="en"?"Enter your location, destination and boarding time to discover available buses.":"உங்கள் இருப்பிடம், செல்லும் இடம் மற்றும் ஏறும் நேரத்தை உள்ளிட்டு கிடைக்கும் பேருந்துகளை கண்டறியுங்கள்.";
 document.querySelector(".find").textContent=language==="en"?"Find Available Buses →":"கிடைக்கும் பேருந்துகளை காண்க →";
 document.getElementById("gov").innerHTML=language==="en"?"🏛 Government":"🏛 அரசு";
 document.getElementById("private").innerHTML=language==="en"?"🚌 Private":"🚌 தனியார்";
}
function showRoute(button){
 const card=button.closest(".bus");
 const stops=JSON.parse(card.dataset.stops);
 const routeBox=card.querySelector(".route-visual");
 const destination=document.getElementById("to").value;
 routeBox.innerHTML=`<div class="route-title">${language==="en"?"Visual Route":"வழித்தடம்"} <span>${stops.length} ${language==="en"?"stops":"நிறுத்தங்கள்"}</span></div>`+
 stops.map((s,i)=>`<div class="stop-row"><div class="dot ${i===0?"start":i===stops.length-1?"end":""}"></div><div><b>${s}</b>${i<stops.length-1?'<div class="connector"></div>':''}</div></div>`).join("");
 routeBox.classList.toggle("open");
 button.textContent=routeBox.classList.contains("open")?(language==="en"?"Hide Route ↑":"வழித்தடத்தை மறைக்க ↑"):(language==="en"?"View Route ↓":"வழித்தடத்தை பார்க்க ↓");
}

function findBuses(){
 const dest=document.getElementById("to").value;
 const wanted=mins(document.getElementById("time").value);
 const all=routes[dest][selectedType]||[];
 let options=[];
 all.forEach(b=>{
   getDepartures(b,dest,selectedType).forEach(d=>{
     if(mins(d.time)>=wanted) options.push({bus:b,time:d.time,initial:d.initial});
   });
 });
 options.sort((a,b)=>mins(a.time)-mins(b.time));
 const el=document.getElementById("results");
 const labels=language==="en" ? {
   available:`Available ${selectedType} buses`,
   next:"NEXT AVAILABLE BUS",
   best:"BEST MATCH",
   view:"View Route ↓",
   fare:"Prototype fare",
   waiting:"after your selected time",
   stops:"stops",
   others:"Other available buses",
   ai:"AI recommendation",
   no:`No ${selectedType.toLowerCase()} buses were found after`,
   forText:"for",
   prototype:"Prototype data: Bus schedules and fares shown here are demonstration data created for the Know My Bus project and are not official government timetables or fares."
 } : {
   available:`கிடைக்கும் ${selectedType==="Government"?"அரசு":"தனியார்"} பேருந்துகள்`,
   next:"அடுத்த கிடைக்கும் பேருந்து",
   best:"சிறந்த தேர்வு",
   view:"வழித்தடத்தை பார்க்க ↓",
   fare:"மாதிரி கட்டணம்",
   waiting:"நீங்கள் தேர்ந்த நேரத்திற்குப் பிறகு",
   stops:"நிறுத்தங்கள்",
   others:"மற்ற கிடைக்கும் பேருந்துகள்",
   ai:"AI பரிந்துரை",
   no:`உங்கள் நேரத்திற்குப் பிறகு ${selectedType==="Government"?"அரசு":"தனியார்"} பேருந்துகள் இல்லை`,
   forText:"க்கு",
   prototype:"மாதிரி தரவு: இங்கு காட்டப்படும் பேருந்து நேரங்கள் மற்றும் கட்டணங்கள் Know My Bus மாதிரிக்காக உருவாக்கப்பட்டவை; இவை அதிகாரப்பூர்வ நேரங்கள் அல்லது கட்டணங்கள் அல்ல."
 };
 document.querySelector(".notice").innerHTML="⚠️ <b>"+labels.prototype.split(":")[0]+":</b>"+labels.prototype.split(":").slice(1).join(":");

 if(!options.length){
   el.innerHTML=`<div class="empty">${labels.no} <b>${fmt(document.getElementById("time").value)}</b> ${labels.forText} ${dest}.</div>`;
   return;
 }

 const fare=fares[dest][selectedType];
 const first=options[0];
 const firstWait=mins(first.time)-wanted;
 const nextCard=`<div class="next-card">
   <div class="small">${labels.next}</div>
   <h3>🚌 ${first.bus[0]}</h3>
   <div class="next-meta">
     <span>🕐 ${fmt(first.time)}</span>
     <span>📍 Pollachi → ${dest}</span>
     <span>⏱ ${firstWait===0?(language==="en"?"Now":"இப்போது"):formatWait(firstWait)+(language==="en"?" away":" தூரம்")}</span>
   </div>
   <div class="fare">💳 ${labels.fare}: ₹${fare}</div>
 </div>`;

 const shown=options.slice(0,5);
 const cards=shown.map((o,i)=>{
   let wait=mins(o.time)-wanted;
   return `<div class="bus" data-stops='${JSON.stringify(o.bus[2])}'>
     <div class="bus-top"><div><div class="bus-name">🚌 ${o.bus[0]}</div><div class="time">${fmt(o.time)}</div></div>${i===0?`<span class="pill">⭐ ${labels.best}</span>`:""}</div>
     <div class="route">Pollachi Bus Stand → ${dest}</div>
     <div class="stops"><b>${labels.stops}:</b> ${o.bus[2].join(" → ")}</div>
     <div class="fare">💳 ${labels.fare}: ₹${fare}</div>
     <div class="route" style="margin-top:8px">⏱ ${wait===0?(language==="en"?"Departs at your selected boarding time.":"நீங்கள் தேர்ந்த நேரத்திலேயே புறப்படும்."):language==="en"?`Leaves ${formatWait(wait)} after your selected time.`:`நீங்கள் தேர்ந்த நேரத்திற்குப் பிறகு ${formatWait(wait)} புறப்படும்.`}</div>
     <button class="route-btn" onclick="showRoute(this)">${labels.view}</button>
     <div class="route-visual"></div>
   </div>`;
 }).join("");

 const ai=`<div class="ai">🤖 <b>${labels.ai}:</b> ${language==="en"?`${first.bus[0]} at ${fmt(first.time)} is the closest available ${selectedType.toLowerCase()} bus after your selected boarding time. The prototype also accounts for the configured return cycle.`:`${fmt(first.time)} மணிக்கு ${first.bus[0]} உங்கள் தேர்ந்த நேரத்திற்குப் பிறகு கிடைக்கும் மிக அருகிலுள்ள ${selectedType==="Government"?"அரசு":"தனியார்"} பேருந்தாகும். இந்த மாதிரி திரும்பும் பேருந்து சுழற்சியையும் கணக்கில் எடுத்துக்கொள்கிறது.`}</div>`;

 el.innerHTML=nextCard+`<div class="result-title"><h2>${labels.available}</h2><span>${labels.others}</span></div>`+cards+ai;
}
