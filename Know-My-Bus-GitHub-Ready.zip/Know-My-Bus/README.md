# 🚌 Know My Bus

Know My Bus is an AI-powered web prototype that helps users find suitable buses based on boarding location, destination, and preferred boarding time.

## Current Prototype

The prototype focuses on Pollachi Bus Stand and selected routes to:
- Coimbatore
- Tiruppur
- Ooty

## Features

- Government / Private bus selection
- Next available bus
- Boarding-time based bus availability
- Bus routes and stops
- Visual route display
- Prototype ticket fare
- English / Tamil interface
- AI recommendation section
- Recurring bus availability based on configured operating cycles

## Important Note

The bus schedules and ticket fares are **prototype/demo data** created for this project. They are not official government timetables or fares and are not connected to a live transport system.

## Files

- `index.html` — main website
- `style.css` — website styling
- `script.js` — bus data, availability logic and interactions
- `data/README.md` — prototype data notes
