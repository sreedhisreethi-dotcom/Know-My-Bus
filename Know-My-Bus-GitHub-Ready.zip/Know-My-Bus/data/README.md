# Prototype Data

The current prototype uses demonstration bus schedules and fares for:
- Pollachi → Coimbatore
- Pollachi → Tiruppur
- Pollachi → Ooty

The data is for educational/demo use and is not official government transport data.
